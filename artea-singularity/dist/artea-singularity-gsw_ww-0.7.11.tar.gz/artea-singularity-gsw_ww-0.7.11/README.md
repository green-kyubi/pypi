# Singularity

Ce module django est la base de chacun de mes projets web.

## Installation
(ça arrive t'inquiète)
