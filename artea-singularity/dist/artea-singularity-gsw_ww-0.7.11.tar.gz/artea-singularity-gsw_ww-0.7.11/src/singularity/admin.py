from django.contrib import admin

from .models import Solaris

# Register your models here.
admin.site.register(Solaris)
